package org.iMage.iLlustrate;

public class mainGenerator {
	
	public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
