package org.iMage.geometrify.parallel;

import static org.junit.Assert.*;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.iMage.geometrify.NonRandomPointGenerator;
import org.iMage.geometrify.TrianglePictureFilter;
import org.junit.Test;

public class ParallelTest {
	
	private BufferedImage imSequence = null;
	private BufferedImage imParallel = null;
	
	
	@Test
	public void testTime() 
	{
		BufferedImage img = null;
		try 
		{
		    img = ImageIO.read(new File("/Users/santiagotafur/Desktop/dices_alpha.png")); 
		    
		} 
		catch (IOException e) 
		{
		    e.printStackTrace();
		}
		
		NonRandomPointGenerator nrpgPara = new NonRandomPointGenerator(img.getWidth(), img.getHeight());
	    NonRandomPointGenerator nrpgNormal = new NonRandomPointGenerator(img.getWidth(), img.getHeight());
	    ParallelTrianglePictureFilter pf = new ParallelTrianglePictureFilter(nrpgPara);
	    TrianglePictureFilter nf = new TrianglePictureFilter(nrpgNormal);
	    
		
		
		long startTime2 = System.nanoTime();
		imSequence = nf.apply(img, 100, 40);
		long endTime2 = System.nanoTime();
		long duration2 = (endTime2 - startTime2);
	   
		long startTime1 = System.nanoTime();
		imParallel = pf.apply(img, 100, 40);
		long endTime1 = System.nanoTime();
		long duration1 = (endTime1 - startTime1);
		
		File outputfile = new File("/Users/santiagotafur/Desktop/parallelDices.png");
	    File outputfile2 = new File("/Users/santiagotafur/Desktop/normalDices.png");
	    
	    try {
			ImageIO.write(imParallel, "png", outputfile);
			ImageIO.write(imSequence, "png", outputfile2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		assertTrue(duration1<duration2);
		
	}
	
	
	
	
	
	
}
